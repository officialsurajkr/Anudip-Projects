package com.ars;

import javax.swing.JOptionPane;

import com.ars.entity.Admin;
import com.ars.entity.Passenger;
import com.ars.model.PassengerDTO;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.PassengerServiceImpl;

public class CrudPassenger 
{
	static PassengerService pservice=new PassengerServiceImpl();
	//this method is responsible to  perform crud operation of passenger
	public static void passenger()
	{
		String pchoice;
		while(true) {
		System.out.println("============================================================================");
System.out.println( "Press r. for read Passenger details\n"
				  + "Press u.for update Passenger details\n"
				  + "Press d.for delete Passenger details\n"
				  + "Press q for quit");
System.out.println("============================================================================");
 pchoice=JOptionPane.showInputDialog("Enter choice","Type here");

 switch(pchoice) {
 

 case "r":

	try {

	
		PassengerDTO pDto=pservice.getPassengerById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
		System.out.println("Passenger details: ");
		System.out.println("Id: "+pDto.getId());
		System.out.println("Name: "+pDto.getName());
        System.out.println("Ph. No: "+pDto.getPhno());
        System.out.println("Email: "+pDto.getEmail());
	}
	catch (Exception e) {
		System.out.println(e);
	}
	
break;
	
 case "u":

	Passenger passenger=new Passenger();
	
	     String name=JOptionPane.showInputDialog("Enter  Name","Type here");
	     String email= JOptionPane.showInputDialog("Enter  Email","Type here");
	     String phno= JOptionPane.showInputDialog("Enter  Phno","Type here");
	     String username= JOptionPane.showInputDialog("Enter Username","Type here");
	     String password= JOptionPane.showInputDialog("Enter Password","Type here");
	//     String role= JOptionPane.showInputDialog("Enter Your Role","Type here");
	      
	       passenger.setName(name);
	       passenger.setEmail(email);
	       passenger.setPhno(phno);
	       passenger.setUserName(username);
	       passenger.setPassword(password);
	       passenger.setRole("User");
	       
	
	PassengerDTO upPass=pservice.updatePassenger(Integer.parseInt(JOptionPane.showInputDialog("enter id to update", "type here")),
			passenger);
	JOptionPane.showMessageDialog(null, "passenger updated successfully");
	
break;	

 case "d":
	pservice.deletePassenger(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
	JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
break;

 case "q":
	
	 CrudOperation.passengerOpearation();
	 break;

 }//end of switch
		}
	} //crud passenger

}
