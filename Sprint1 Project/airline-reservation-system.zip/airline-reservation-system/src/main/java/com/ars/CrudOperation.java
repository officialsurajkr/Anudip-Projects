package com.ars;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import com.ars.dao.AdminDAO;
import com.ars.entity.Admin;
import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.entity.Passenger;
import com.ars.entity.TicketGenerationPdf;
import com.ars.model.AdminDTO;
import com.ars.model.AirlineDTO;
import com.ars.model.FlightDTO;
import com.ars.model.PassengerDTO;
import com.ars.model.TicketBookingDTO;
import com.ars.service.AdminService;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.PassengerService;
import com.ars.service.TicketService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;
import com.ars.serviceimpl.TicketServiceImpl;

public class CrudOperation {

	
	static FlightService fService=new FlightServiceImpl();
	static AirlineService aService=new AirlineServiceImpl();
	static TicketService tService=new TicketServiceImpl();
	
	
	
		//sub menu to choose menu
		public static void passengerOpearation()
		{

	    	int input;
	    	while(true) {
	    		System.out.println("============================================================================");
	    	System.out.println("Press 1. for Passenger details\n"
	    					  +"Press 2. for check flights\n"
	    					  +"Press 3. for book flight tickes\n"
	    					  +"Press 4. for Boarding Pass\n"
	    					  +"Press 5. for cancel flight ticket\n"
	    					  +"Press 6. for quit");
	         input=Integer.parseInt(JOptionPane.showInputDialog("Enter choice","Type here"));
	    	System.out.println("============================================================================");
	    	
	    	switch(input){
	    		
	    	case 1:
	    	CrudPassenger.passenger();
	           break;
	    	
	    	case 2:
	    		List<Flight> flights= fService.checkFlight(JOptionPane.showInputDialog("Enter From","Type here"),
         			JOptionPane.showInputDialog("Enter To","Type here"));
            
         	for(Flight flight: flights)
         	{
         		
         		System.out.println("Flight Id : "+flight.getFlight_id());
    			System.out.println("Airline Name : "+flight.getAirline().getAirlineName());
    			System.out.println("Flight Date : "+flight.getDate());
    			System.out.println("Flight Source : "+flight.getSource());
    			System.out.println("Flight Destination : "+flight.getDestination());
    			System.out.println("Flight Time : "+flight.getTime());
    			System.out.println("Flight Class : "+flight.getTravellerClass());
    			System.out.println("Flight AvailableSeats : "+flight.getAvailableSeats());
         	}
	    		break;
	    		
	    	case 3:
	    		CrudTicketBooking.bookFlight();
	    		break;
	    	case 4:
	    		try {
					TicketBookingDTO tdto=tService.getTicketById(Integer.parseInt(JOptionPane.showInputDialog("Enter Ticket Id", "type here")));
						System.out.println("==============================================================================================");
					System.out.println("-------Flight Boarding Pass Deatils---------- ");
			
						System.out.println(" Flight Id: "+tdto.getFlightId().getFlight_id()+" \t "
										  +" Airline: "+tdto.getAirlineId().getAirlineName()+" \t "
										  +" Source: "+tdto.getFlightId().getSource() +" \t "
										  +" Destination: "+tdto.getFlightId().getDestination()+" \n "
										  +" Passenger Name: "+tdto.getPassengerId().getName() +" \t "
										  +" Passenegr Email: "+tdto.getPassengerId().getEmail()+ " \t "
										  +" No of passenger: "+tdto.getNo_of_passenger() +" \n "
										  +" Date: "+tdto.getDate()+" \t "
										  +" Time: "+tdto.getFlightId().getTime()+" \t"
										  +" Class: "+tdto.getFlightId().getTravellerClass()+" \n "
										  +" Total fare: "+tdto.getTotalFare());
						
	    		}
	    		catch (Exception e) {
	    		System.out.println("id not found");
	    		}
	    			
	    		break;
	    	case 5:
	    		CrudTicketBooking.cancelTicket();
	    		break;
	    	case 6:
	    		App.mainMenu();
	    		break;
	    		
	    	}
	    	}
		}
	    	public static void AdminOpeartion()
			{

		    	int input;
		    	while(true) {
		    		System.out.println("============================================================================");
		    	System.out.println("Press 1. for Admin details\n"
		    					  +"Press 2. for Flight details\n"
		    					  +"Press 3. for airline details\n"
		    					  +"Press 4. for add flight to airlines\n"
		    					  +"Press 5. for quit");
		         input=Integer.parseInt(JOptionPane.showInputDialog("Enter choice","Type here"));
		    	System.out.println("============================================================================");
		    	
		    	switch(input){
		    	
		    	case 1:
		    		
		    		CrudAdmin.admin();
		    		break;
		    		
		    	case 2:
		    		CrudFlight.flight();
		           break;
		    	
		    	case 3:
		    	
		    		CrudAirline.airline();
		    		break;
    		
		    	case 4:
		    		CrudTicketBooking.assignAirlineToFlight();
		    		break;
		    	case 5:
		    		App.mainMenu();
		    		break;
		    		
	    	}
		    	}	
		    	
		}
}
