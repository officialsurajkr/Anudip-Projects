package com.ars.model;

import java.util.List;
import com.ars.entity.Flight;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AirlineDTO
{
	private int id;
	
	@NotNull(message = "{a.airlinename.check}")
	@Size(min = 2,message = "{a.airlinesize.check}")
	private String airlineName;
	
	@NotNull(message = "{a.airlinefare.check}")

	private float fare;
	
	List<Flight> flights;

	public AirlineDTO(
			@NotNull(message = "{a.airlinename.check}") @Size(min = 2, message = "{a.airlinesize.check}") String airlineName,
			@NotNull(message = "{a.airlinefare.check}") float fare) {
		super();
		this.airlineName = airlineName;
		this.fare = fare;
		
	}

	
	
	
	

}
