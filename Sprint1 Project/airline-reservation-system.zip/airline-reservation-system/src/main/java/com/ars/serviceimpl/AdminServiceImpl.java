package com.ars.serviceimpl;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.dao.AdminDAO;
import com.ars.daoimpl.AdminDAOImpl;
import com.ars.entity.Admin;

import com.ars.exception.GlobalException;
import com.ars.model.AdminDTO;

import com.ars.service.AdminService;


public class AdminServiceImpl implements AdminService{
	
	private static final Logger Logger=LoggerFactory.getLogger(AdminServiceImpl.class);

	AdminDAO aDao=new AdminDAOImpl();
	
	@Override
	public void registerAdmin(Admin admin) {
		aDao.registerAdmin(admin);
		Logger.info("inside save admin method: ");
	}

	@Override
	public boolean loginAdmin(String userName, String password) {
		Logger.info("inside login admin method: ");
		return aDao.loginAdmin(userName, password);
		
	}

	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {
	
		Admin a=aDao.updateAdmin(id, admin);
		Logger.info("inside update admin method: ");
		return new ModelMapper().map(a, AdminDTO.class); //converting entity to DTO
		
	}

	@Override
	public AdminDTO getAdminById(int id) throws GlobalException {
		Admin admin	=aDao.getAdmin(id);
		if(admin!=null)
		{
			Logger.info("inside updateById admin method: ");
			return new ModelMapper().map(admin, AdminDTO.class);
		}
			throw new GlobalException("Admin details not exist!!");
		}
	

	@Override
	public void deleteAdmin(int id) {
		Logger.info("inside delete admin method: ");
		aDao.deleteAdmin(id);
		
	}

}
