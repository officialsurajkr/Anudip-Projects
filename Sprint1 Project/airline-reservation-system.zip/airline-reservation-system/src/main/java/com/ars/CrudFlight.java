package com.ars;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.swing.JOptionPane;

import com.ars.entity.Flight;
import com.ars.model.FlightDTO;
import com.ars.service.FlightService;
import com.ars.serviceimpl.FlightServiceImpl;

public class CrudFlight 
{
	static FlightService fService=new FlightServiceImpl();
	
	//this method is responsible to  perform crud operation of flight
	public static void flight()
		{
			String in;
				while(true) {
				System.out.println("============================================================================");
				System.out.println("Press c. for add Flight details\n"
								  +"Press r. for flight details\n"
								  +"Press u.for update flight details\n"
								  +"Press d.for delete flight details\n"
								  +"Press q for quit ");
			System.out.println("============================================================================");
			in=JOptionPane.showInputDialog("Enter choice","Type here");
			
			switch(in) {
			case "c":
				 Flight flight=new Flight();
				
				int availableSeat=(Integer.parseInt(  JOptionPane.showInputDialog("Enter Available Seats","Type here")));
				int totalSeats=(Integer.parseInt(  JOptionPane.showInputDialog("Enter Total Seats","Type here")));
				String travelClass= JOptionPane.showInputDialog("Enter Travel Class","Type here");
				String time=(JOptionPane.showInputDialog("Enter Flight Time","Type here"));
				LocalDate date=LocalDate.parse(JOptionPane.showInputDialog("Enter Flight Date","YYYY-MM-DD"));
				String source=(JOptionPane.showInputDialog("Enter Flight Source","Type here"));
				String destination=(JOptionPane.showInputDialog("Enter Flight Destination","Type here"));
				
				
			        
			         flight.setAvailableSeats(availableSeat);
			         flight.setTotalSeats(totalSeats);
			         flight.setTravellerClass(travelClass);
			         flight.setTime(time);		       
			         flight.setDate(date);
			         flight.setSource(source);
			         flight.setDestination(destination);
			        
			         			         
			         fService.saveFlight(flight);
			         System.out.println("Flight added successfully!! \n Flight id is "+flight.getFlight_id());
		       break;
			

			case "r":
				
				 try {
					
					FlightDTO fdto=fService.getFlight(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
						System.out.println("Admin details: ");
						System.out.println("Flight Id: "+fdto.getFlight_id());
						System.out.println("AvailableSeats : "+fdto.getAvailableSeats());
				        System.out.println("TotalSeats: "+fdto.getTotalSeats());
				        System.out.println("flight class: "+fdto.getTravellerClass());
				        System.out.println("Travel Time: "+fdto.getTime());
				        System.out.println("Travel date: "+fdto.getDate());
				        System.out.println("Source : "+fdto.getSource());
				        System.out.println("Destination: "+fdto.getDestination());	
						
		}
		catch (Exception e) {
		System.out.println("id not found");
		}
					
				
		   break;
			case "u":
					Flight flight1=new Flight();
					
	int availSeat=(Integer.parseInt(  JOptionPane.showInputDialog("Enter Available Seats","Type here")));
	int tSeats=(Integer.parseInt(  JOptionPane.showInputDialog("Enter Total Seats","Type here")));
	String tClass= JOptionPane.showInputDialog("Enter Travel Class","Type here");
	String time1=(JOptionPane.showInputDialog("Enter Flight Time","Type here"));
	LocalDate date1=LocalDate.parse(JOptionPane.showInputDialog("Enter Flight Date","YYYY-MM-DD"));
	String fsource=(JOptionPane.showInputDialog("Enter Flight Source","Type here"));
	String fdestination=(JOptionPane.showInputDialog("Enter Flight Destination","Type here"));
					
					flight1.setAvailableSeats(availSeat);
					flight1.setTotalSeats(tSeats);
					flight1.setTravellerClass(tClass);
					flight1.setTime(time1);
			        flight1.setDate(date1);
			        flight1.setSource(fsource);
			        flight1.setDestination(fdestination);
			        
			        fService.updateFlight(Integer.parseInt(JOptionPane.showInputDialog
					("enter flight id to update", "type here")), flight1);
			        
			        System.out.println("Flight updated successfully");
		   
		  break;
//				
			case "d":
				
				
				fService.deleteFlight(Integer.parseInt(JOptionPane.showInputDialog("enter flight id to delete", "type here")));
		   
						JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
		   break;
			case "q":
				
				CrudOperation.AdminOpeartion();
				break;
				default:System.out.println("wrong input");
//			
		}//switch 
			}
	} //crud flight
}
