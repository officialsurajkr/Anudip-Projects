package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Admin;
import com.airline.entity.Flight;
import com.airline.model.FlightDTO;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

public class FlightRepositoryTest 
{
	@Autowired
	private FlightRepository flightRepository;
	
	@Autowired
	FlightService flightService;
	
	@Autowired
	FlightConverter flightConverter;
	
	//this method is for testing saveFlight Repository layer
//	@Test
//	@Rollback(value = false)
//	@Order(1)
//	@DisplayName("saveFlight method")
//	void saveFlightTest()
//	{
//		Flight flight=Flight.builder().availableSeats(120).totalSeats(200).travellerClass("economy").
//				time("10:20 ").date(LocalDate.parse("2022-10-12")).source("delhi").destination("mumbai").build();
//		
//		Flight f=flightRepository.save(flight);
//		assertThat(f.getAvailableSeats()).isEqualTo(120);
//
//	}
	
	//this method is for testing getAllFlight Repository layer
	@Test
	@DisplayName("getAllFlight method")
	@Rollback(value = false)
	@Order(3)
	void getAllFlightTest()
	{
		List<Flight> list=flightRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	//this method is for testing updateFlight Repository layer
	
	@Test
	@DisplayName("updateFlight method")
	@Rollback(value = false)
	@Order(2)
	void updateFlightTest()
	{
		Flight exFlight=flightRepository.findById(15).get();
		exFlight.setAvailableSeats(100);
		
		Flight f=flightRepository.save(exFlight);
		assertThat(f.getAvailableSeats()).isEqualTo(100);
	}
	
	//this method is for testing deleteFlight Repository layer
	
	@Test
	@DisplayName("deleteFlight method")
	@Order(4)
	void deleteFlightTest()
	{
		flightRepository.deleteById(16);
		assertThrows(NoSuchElementException.class,()-> flightRepository.findById(16).get());
		
	}
	
	//this method is for testing negative case updateFlight Repository layer
	
	@Test
	@DisplayName("negative test case")
	@Rollback(value = false)
	@Order(5)
	void updateFlightNegative()
	{
		Flight exflight=flightRepository.findById(15).get();
		exflight.setSource("Mumbai");
		Flight f=flightRepository.save(exflight);
		
		assertThat(f.getSource()).isEqualTo("kolkata");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
