package com.airline.controller;

import java.util.Date;

import javax.servlet.ServletException;


import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.airline.entity.Passenger;
import com.airline.entity.User;
import com.airline.service.PassengerService;
import com.airline.service.TicketBookingService;
import com.airline.util.PassengerConverter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@WebMvcTest(PassengerController.class)
public class PassengerControllerTest {
	
	//logger statically created
			private static final Logger L=LoggerFactory.getLogger(PassengerController.class);

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private PassengerService passengerService;
	
	
	@MockBean
	PassengerConverter passengerConverter;
	
	String jwtToken="";
	
	
	User user;
	
	@BeforeEach
	void setUp()
	{

	    user=new User();
		user.setUserName("john");
		user.setPassword("pass123");
		user.setRole("user");
	}
	
public String tokenCreation() throws ServletException
{
	 jwtToken=Jwts.builder().setSubject(user.getUserName()).claim("roles", user.getRole()).
			    setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, "secretkey").compact();
	 return jwtToken;
}


//this method is for testing savePassenger Controller layer
@Test
@DisplayName("savePassenger method")
 void testSavePassenger() throws Exception {
	String accessToken = tokenCreation();

	System.out.println(accessToken);
	
	
	 String jsonString = new JSONObject()
	            .put("id", 101)
	            .put("name", "john")
	            .put("phno", "9904367865")
	            .put("email", "john@gmail.com")
	            .put("userName", "john")
	            .put("password", "pass123")
	            .put("role", "user")
	            .toString();
	
	mockMvc.perform(MockMvcRequestBuilders.post("/api/createPassenger").
			contentType(MediaType.APPLICATION_JSON)
			.content(jsonString)
			.header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken))
			.andExpect(MockMvcResultMatchers.status().isOk());
	
	L.info("Passenger"+jsonString.toString()+" added at "+ new java.util.Date());
}
}
