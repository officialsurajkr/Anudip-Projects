package com.airline.controller;

import java.util.Date;

import javax.servlet.ServletException;


import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.airline.entity.Admin;
import com.airline.service.AdminService;
import com.airline.util.AdminConverter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@WebMvcTest(AdminController.class)
public class AdminControllerTest {
	
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AdminService adminpassengerService;
	
	
	@MockBean
	AdminConverter adminConverter ;
	
	String jwtToken="";
	
	
	Admin admin;
	
	@BeforeEach
	void setUp()
	{

	   
	    admin =new Admin();
	    admin.setUserName("admin");
	    admin.setPassword("admin123");
	    admin.setRole("admin");
		
	}
	
public String tokenCreation() throws ServletException
{
	jwtToken=Jwts.builder().setSubject(admin.getUserName()).claim("role", admin.getRole()).
			setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, "secretkey").compact();
	
	 return jwtToken;
}


//this method is for testing saveAdmin Controller layer
@Test
@DisplayName("saveAdmin method")
 void testSaveAdmin() throws Exception {
	String accessToken = tokenCreation();

	System.out.println(accessToken);
	
	
	 String jsonString = new JSONObject()
	            .put("id", 101)
	            .put("aname", "john")
	            .put("aphno", "9904367800")
	            .put("aemail", "johnk@gmail.com")
	            .put("userName", "admin")
	            .put("password", "admin123")
	            .put("role", "admin")
	            .toString();
	
	mockMvc.perform(MockMvcRequestBuilders.post("/api/createAdmin").
			contentType(MediaType.APPLICATION_JSON)
			.content(jsonString)
			.header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken))
			.andExpect(MockMvcResultMatchers.status().isOk());
	L.info("Admin "+jsonString.toString()+" added at "+ new java.util.Date());
}

}
