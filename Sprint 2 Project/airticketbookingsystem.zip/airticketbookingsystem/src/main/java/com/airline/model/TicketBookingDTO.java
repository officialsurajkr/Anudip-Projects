package com.airline.model;

import java.time.LocalDate;


import javax.validation.constraints.NotNull;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@Data
public class TicketBookingDTO {
private int ticketId;
	
    @NotNull(message = "Numbeer of Passenger field can't be null")
	private int no_of_passenger;
    
   
	private float totalFare;
	
	@NotNull(message = "date field can't be null")
	private LocalDate date=LocalDate.now();


    private String source;
	
	private String destination;
	
	private Flight fId;
	
	private Airline aId;
	
	private Passenger pId;
	
}
