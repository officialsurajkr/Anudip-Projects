package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Flight;
import com.airline.model.FlightDTO;



@Component
public class FlightConverter {
	
	//convert from FlightDTO to Entity(flight)
		public Flight covertToFlightEntity(FlightDTO flightDTO)
		{
			Flight flight=new Flight();
			if(flightDTO!=null)
			{
				BeanUtils.copyProperties(flightDTO, flight);
			}
			return flight;
		}
		
		
		//covert from flight Entity to FlightDTO
		public FlightDTO convertToFlightDTO(Flight flight)
		{
			FlightDTO flightDTO=new FlightDTO();
			if(flight!=null)
			{
				BeanUtils.copyProperties(flight, flightDTO);
			}
			return flightDTO;
		}
		
}
