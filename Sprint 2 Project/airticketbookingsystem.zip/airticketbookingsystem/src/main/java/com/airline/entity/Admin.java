package com.airline.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

@Table(name = "register_admin")
public class Admin extends User{
    @Column(name = "admin_Name",length = 50,nullable = false)
	private String aname;
    
    @Column(length = 10,nullable = false, unique = true)
	private String aphno;
   
    @Column(name = "email",length = 100,nullable=false)
	private String aemail;

    @Builder
	public Admin(int id, String userName, String password, String role, String aname, String aphno, String aemail) {
		super(id, userName, password, role);
		this.aname = aname;
		this.aphno = aphno;
		this.aemail = aemail;
	}
    
    
    
    
   
    
  
	
    
    
}


