package com.airline.service;


import java.util.List;

import com.airline.entity.TicketBooking;
import com.airline.model.TicketBookingDTO;

public interface TicketBookingService {

	String bookFlight(int fid, int pid, TicketBooking ticketBooking);
	String cancelBooking(int id);
	TicketBookingDTO getBoardingPass(int id);
	List<TicketBookingDTO> getAllBookingTicket();
}
