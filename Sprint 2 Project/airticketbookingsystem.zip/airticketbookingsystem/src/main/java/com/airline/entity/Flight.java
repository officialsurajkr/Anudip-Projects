package com.airline.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int flight_id;

	@Column(name = "available_seats")
	private int availableSeats;

	@Column(name = "total_seats")
	private int totalSeats;

	@Column(length = 50)
	private String travellerClass;
	
     
	private String time;
     
   
	private LocalDate date;

	@Column(length = 50)
	private String source;
	
	@Column(length = 50)
	private String destination;

	@ManyToOne
	@JoinColumn(name = "airline_id")
	@JsonIgnoreProperties("flights")
	private Airline airline;

	@Builder
	public Flight(int availableSeats, int totalSeats, String travellerClass, String time, LocalDate date, String source,
			String destination, Airline airline) {
		super();
		this.availableSeats = availableSeats;
		this.totalSeats = totalSeats;
		this.travellerClass = travellerClass;
		this.time = time;
		this.date = date;
		this.source = source;
		this.destination = destination;
		this.airline = airline;
	}

	
	

	
	
	
	
}
