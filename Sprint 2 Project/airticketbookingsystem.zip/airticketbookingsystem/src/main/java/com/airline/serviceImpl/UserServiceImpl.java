package com.airline.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.User;
import com.airline.repository.UserRepository;
import com.airline.service.AdminService;
import com.airline.service.UserService;

@Service
public class UserServiceImpl implements UserService
{
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(AdminService.class);
	
	@Autowired
	UserRepository userRepository;

	
	//Service layer for login
	@Override
	public User login(String userName, String password) {
		
		User user=userRepository.findByUserNameAndPassword(userName, password);
		
		L.info(user.getUserName()+" logged in succesfully as "+user.getRole()+" at "+ new java.util.Date());
		
		return user;
		
	}

}
